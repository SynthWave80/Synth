using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace ProjetAlpha.Model
{

    public class Presence : DbContext
    {
        [Key] public int PresenceID{get;set;}

     [Required] public int SeanceID {get;set;}
     [Required] public int EtudiantID {get;set;}
     [Required] public int FilliereID { get; set; }

     [ForeignKey("Matiere")] [Required] public int MatiereID { get; set; }
     [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd.MM.yyyy. HH:mm}")]
     public DateTime ToDate { get; set; }


        [ForeignKey("SeanceID")] public Seance seance {get;set;}
     [ForeignKey("EtudiantID")] public Etudiant etudiant {get;set;}

      



    }


}