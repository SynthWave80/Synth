using Microsoft.AspNetCore.Identity;
namespace ProjetAlpha.Model
{
    public class ApplicationUser : IdentityUser
    {
        public string status{get;set;}
        public string Name {get;set;}
        public string telephone{get;set;}
    }
}