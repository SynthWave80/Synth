using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Microsoft.EntityFrameworkCore;


namespace ProjetAlpha.Model
{

    public class Matiere : DbContext
    {
        [Key] public int MatiereID{get;set;}

        public string ProfID {get;set;}

        [Required] public string name{get;set;}

        [Required] public int filiereId{get;set;}

        [ForeignKey("FilliereID")] public Filliere filliere{get;set;}

         

     




    }


}