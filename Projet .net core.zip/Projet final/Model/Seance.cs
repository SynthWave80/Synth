using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace ProjetAlpha.Model
{

    public class Seance : DbContext
    {
        [Key] public int SeanceID{get;set;}

  
     [Required] public int FilliereID;

    
     [Required] public int matiereID{get;set;}

     [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd.MM.yyyy. HH:mm}")]
        public DateTime ToDate { get; set; }


    // [Required]public int ProfesseurID{get;set;}

   
     [Required]public int presenceID{get;set;}

     public int Groupe {get;set;}
     [ForeignKey("MatiereID")] public Matiere matiere{get;set;}
    [ForeignKey("FilliereID")] public Filliere Filliere{get;set;}
    
     //[ForeignKey("ProfesseurID")] public Professeur professeur{get;set;}
     [ForeignKey("PresenceID")] public Presence presence{get;set;}

    }


}