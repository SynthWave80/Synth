using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations ;
using Microsoft.EntityFrameworkCore;
using ProjetAlpha.Data;
using ProjetAlpha.Model;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;

namespace ProjetAlpha.Pages
{
    public class DeleteProfModel : PageModel
    {
       public ApplicationUser user {get; set;}

        private ILogger<DeleteProfModel> _logger ;

        private readonly ApplicationDbContext _db ;


        public DeleteProfModel(ILogger<DeleteProfModel> logger , ApplicationDbContext db)
        {
            _logger = logger;
            _db = db ;
        }
        
        public void OnGet(string id)
        {
            user = _db.ApplicationUser.Find(id);
            var result = _db.ApplicationUser.Remove(user) ;
            _db.SaveChanges();
        }
    }
}
