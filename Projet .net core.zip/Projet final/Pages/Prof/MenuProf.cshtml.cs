using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations ;
using Microsoft.EntityFrameworkCore;
using ProjetAlpha.Data;
using ProjetAlpha.Model;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;

namespace ProjetAlpha.Pages
{
    public class MenuProfModel : PageModel
    {
        private readonly ILogger<MenuProfModel> _logger;
public IEnumerable<ApplicationUser> users{get; set;}

        private readonly ApplicationDbContext _db ;
        public MenuProfModel(ILogger<MenuProfModel> logger , ApplicationDbContext db)
        {
            _logger = logger;
            _db = db ;
        }
           public async Task OnGetAsync()
        {
            users = await _db.ApplicationUser.Where(s => s.status=="Prof" )
            .ToListAsync();
            }
    }
}
