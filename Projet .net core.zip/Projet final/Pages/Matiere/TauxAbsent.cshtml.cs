﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using ProjetAlpha.Model;
using ProjetAlpha.Data;
using System.Linq;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace ProjetAlpha.Pages
{

    public class TauxAbsentModel : PageModel
    {
        private readonly ILogger<TauxAbsentModel> _logger;

        public Model.Presence Fillieres { get; set; }

        public string Nom { get; set; }

        private readonly ApplicationDbContext _db;

        public double Presences { get; set; }

        public IEnumerable<Model.Etudiant> Etudiants { get; set; }

        public double Var1 { get; set; }

        public double Var2 { get; set; }

        public double Tab1 { get; set; }
        

        public double ttletfl;

        public double x;



        [Required]
        public string Id { get; set; }

        public TauxAbsentModel(ILogger<TauxAbsentModel> logger, ApplicationDbContext db)
        {
            _logger = logger;
            _db = db;
        }


        public async Task OnGetAsync(int id)
        {
            Fillieres= _db.Presences.Where(s => s.MatiereID == id).FirstOrDefault();

            Presences = _db.Presences.Where(p => p.MatiereID == id).Count();

            Etudiants = await _db.Etudiants.ToListAsync();

            Nom = _db.Matiere.Where(m => m.MatiereID == id).Select(m => m.name).First();

        }


    }
}

