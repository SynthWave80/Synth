using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations ;
using Microsoft.EntityFrameworkCore;
using ProjetAlpha.Data;
using ProjetAlpha.Model;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;

namespace ProjetAlpha.Pages
{   [Authorize]
    public class AddMatiereModel : PageModel
    {
        private readonly ApplicationDbContext _db ;
         public IEnumerable<Model.Filliere> Filieres {get; set;}
        public IEnumerable<ApplicationUser> Users { get; set; }

        [BindProperty]
        public InputModel Input { get; set; }

        public string ReturnUrl { get; set; }

         public AddMatiereModel(ApplicationDbContext db){
            _db = db ;
        }
        public class InputModel
        {
            
            [Required]
            public string Name { get; set; }
            [Required]
            public int IdFilieres { get; set; }

            [Required]
            public string IdProf { get; set; }
        }
        
           public async Task OnGetAsync()
        {
            Filieres = await _db.Fillieres
            .ToListAsync();

            Users = await _db.ApplicationUser.Where(s => s.status == "Prof")
            .ToListAsync();
        }
 
        public IActionResult OnPost(string returnUrl = null){
            

            returnUrl = returnUrl ?? Url.Content("~/");

    if (ModelState.IsValid)
            {
                var mt = new Model.Matiere
                {
                    name = Input.Name,
                    filiereId = Input.IdFilieres,
                  ProfID = Input.IdProf
            };

            _db.Matiere.Add(mt);

            _db.SaveChanges();
            
        }
            return LocalRedirect(returnUrl);
    
}}}
