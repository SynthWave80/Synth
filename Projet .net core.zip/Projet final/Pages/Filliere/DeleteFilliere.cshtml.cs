using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations ;
using Microsoft.EntityFrameworkCore;
using ProjetAlpha.Data;
using ProjetAlpha.Model;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;

namespace ProjetAlpha.Pages
{
    [Authorize]
    public class DeleteFilliereModel : PageModel
    {
        public Model.Filliere fD {get; set;}

        private ILogger<DeleteFilliereModel> _logger ;

        private readonly ApplicationDbContext _db ;


        public DeleteFilliereModel(ILogger<DeleteFilliereModel> logger , ApplicationDbContext db)
        {
            _logger = logger;
            _db = db ;
        }



        public void OnGet(int id)
        {
            fD = _db.Fillieres.Find(id);
            var result = _db.Fillieres.Remove(fD) ;
            _db.SaveChanges();
        }
    }
}