using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations ;
using Microsoft.EntityFrameworkCore;
using ProjetAlpha.Data;
using ProjetAlpha.Model;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;

namespace ProjetAlpha.Pages
{
    [Authorize]
    public class MenuFilliereModel : PageModel
    {

       private readonly ILogger<MenuFilliereModel> _logger;


        private readonly ApplicationDbContext _db ;

        public IEnumerable<Model.Filliere> Filieres {get; set;}

        [Required]
        public string Id { get; set; }

        public MenuFilliereModel(ILogger<MenuFilliereModel> logger , ApplicationDbContext db)
        {
            _logger = logger;
            _db = db ;
        }


        public async Task OnGetAsync()
        {
            Filieres = await _db.Fillieres
            .ToListAsync();

        }
    }
}
