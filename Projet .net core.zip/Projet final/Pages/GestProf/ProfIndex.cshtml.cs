﻿
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using ProjetAlpha.Data;
using System.Collections.Generic;
using System.Threading.Tasks;
using ProjetAlpha.Model;
using Microsoft.AspNetCore.Identity;
using System.Linq;
using Microsoft.AspNetCore.Authorization;



namespace ProjetAlpha.Pages.GestProf
{
    public class ProfIndexModel : PageModel
    {

        private readonly ILogger<ProfIndexModel> _logger;

        private readonly UserManager<IdentityUser> _userManager;
        private readonly SignInManager<IdentityUser> _signInManager;

        private readonly ApplicationDbContext _db;

        public ApplicationUser Prof { get; set; }


        public ProfIndexModel(SignInManager<IdentityUser> signInManager,
            ILogger<ProfIndexModel> logger,
            UserManager<IdentityUser> userManager,
            ApplicationDbContext db)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _logger = logger;
            _db = db;
        }

        public async Task OnGet()
        {
            var user = await _userManager.GetUserAsync(HttpContext.User);
            Prof = _db.ApplicationUser
                            .Where(PF => PF.Id == user.Id)
                            .First();

        }
    }
}


