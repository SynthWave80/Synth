﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ProjetAlpha.Data;
using ProjetAlpha.Model;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
namespace ProjetAlpha.Pages.GestProf
{


    public class GestEtudModel : PageModel
    {
        private readonly ILogger<GestEtudModel> _logger;


        private readonly ApplicationDbContext _db;

        public IEnumerable<Etudiant> dpEt { get; set; }

        public IEnumerable<Model.Matiere> Mat { get; set; }
        


        public GestEtudModel(ILogger<GestEtudModel> logger, ApplicationDbContext db)
        {
            _logger = logger;
            _db = db;
        }


        public async Task OnGetAsync(string id)
        {
            Mat = await _db.Matiere.Where(m => m.ProfID == id).ToListAsync();
        }
    }

}





