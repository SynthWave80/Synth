﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ProjetAlpha.Data;
using ProjetAlpha.Model;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;

using Microsoft.AspNetCore.Authorization;

namespace ProjetAlpha.Pages.GestProf
{
    public class StatsEtudModel : PageModel
    {
        public IEnumerable<Etudiant> Et { get; set; }

        private readonly ILogger<StatsEtudModel> _logger;

        private readonly UserManager<IdentityUser> _userManager;

        public int Idd { get; set; }

        private readonly SignInManager<IdentityUser> _signInManager;

        private readonly ApplicationDbContext _db;


        public List<int> filiers { get; set; }


        public StatsEtudModel(SignInManager<IdentityUser> signInManager,
            ILogger<StatsEtudModel> logger,
            UserManager<IdentityUser> userManager,
            ApplicationDbContext db)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _logger = logger;
            _db = db;
        }


        public async Task OnGetAsync(int id)
        {
            filiers = await _db.Seances.Where(m => m.matiereID == id).Select(f => f.FilliereID).ToListAsync();

            Et = await _db.Etudiants.ToListAsync();

            Idd = id;

        }
    }
}

