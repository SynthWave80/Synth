package com.example.projetequit;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;



public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    Button bLogin;
    EditText etUser,etPassword;
    TextView tvRegister;
    UserLocalStore Userlcs;
    User user;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUser =(EditText) findViewById(R.id.etEmail);
        etPassword=(EditText) findViewById(R.id.etPassword);
        bLogin =(Button) findViewById(R.id.bLogin);
        tvRegister=(TextView) findViewById(R.id.tvRegister);

        bLogin.setOnClickListener(this);
        tvRegister.setOnClickListener(this);

        Userlcs = new UserLocalStore(this);



    }
    @Override
    public void onClick(View v) {

        switch(v.getId()){

            case R.id.bLogin:

                User user = new User(null,null);
                Userlcs.StoreUserData(user);
                Userlcs.setUserLoggedIn(true);

                break;

            case R.id.tvRegister:

                startActivity(new Intent(this, RegisterActivity.class));


                break;
        }



    }
}
