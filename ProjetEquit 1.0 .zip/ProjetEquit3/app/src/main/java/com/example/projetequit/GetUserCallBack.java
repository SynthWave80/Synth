package com.example.projetequit;

interface GetUserCallBack {

    public abstract void done(User returnedUser);
}
