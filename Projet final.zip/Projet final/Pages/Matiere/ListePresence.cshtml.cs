﻿using System.Threading.Tasks;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using ProjetAlpha.Model;
using ProjetAlpha.Data;
using System.Linq;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;

namespace ProjetAlpha.Pages

{

    public class ListPresenceModel : PageModel
    {
        private readonly ILogger<ListPresenceModel> _logger;


        private readonly ApplicationDbContext _db;

        public IEnumerable<Model.Presence> Presences { get; set; }


        public IEnumerable<Etudiant> Etudiants { get; set; }

        public IEnumerable<int> res;



        [Required]
        public string Id { get; set; }

        public ListPresenceModel(ILogger<ListPresenceModel> logger, ApplicationDbContext db)
        {
            _logger = logger;
            _db = db;
        }


        public async Task OnGetAsync(int id)
        {
            Etudiants = await _db.Etudiants.ToListAsync();

            Presences = await _db.Presences
                    .Where(p => p.MatiereID == id)
                    .ToListAsync();

            res = Presences.AsQueryable().Select(etudiant => etudiant.EtudiantID);
        }


    }
}