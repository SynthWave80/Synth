using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using ProjetAlpha.Data;
using ProjetAlpha.Model;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;

namespace ProjetAlpha.Pages
{
    [Authorize]
    public class UpdateFilliereModel : PageModel
    {
      private readonly ApplicationDbContext _db ;
         [BindProperty]
        public InputModel Input { get; set; }
        public Model.Filliere fl {get; set;}

        public int Fid {get; set;}
  public class InputModel{

            [Required]
            public string NFil {get; set;}
        }

        private ILogger<UpdateFilliereModel> _logger ;
       

         public UpdateFilliereModel (ILogger<UpdateFilliereModel> logger , ApplicationDbContext db)
        {
            _logger = logger;
            _db = db ;
        }

  public async Task OnGetAsync(int id)
        {
            
            fl = await _db.Fillieres.FindAsync(id);
            Fid = id ;
        }
      
            public IActionResult OnPost(int id)
        {                          
              
            fl = _db.Fillieres.Find(id);
            fl.name = Input.NFil ;
            _db.Fillieres.Update(fl);
            
            _db.SaveChanges();

            return RedirectToPage("/Index");
        }
    }
}