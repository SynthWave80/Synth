using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations ;
using Microsoft.EntityFrameworkCore;
using ProjetAlpha.Data;
using ProjetAlpha.Model;
using Microsoft.AspNetCore.Authorization;

namespace ProjetAlpha.Pages
{   [Authorize]
    public class AddFilliereModel : PageModel
    {
      private readonly ApplicationDbContext _db ;
        

        [BindProperty]
        public InputModel Input { get; set; }

        public string ReturnUrl { get; set; }

         public AddFilliereModel(ApplicationDbContext db){
            _db = db ;
        }

        
        public class InputModel
        {
            
            [Required]
            public string Name { get; set; }

        }

          public void OnGet(string returnUrl = null)
        {
                        ReturnUrl = returnUrl;
        }

          public IActionResult OnPost(string returnUrl = null){
            

            returnUrl = returnUrl ?? Url.Content("~/");

            if (ModelState.IsValid)
            {
                var fl = new Model.Filliere {
                  name = Input.Name 
            };

            _db.Fillieres.Add(fl);

            _db.SaveChanges();
            
        }
            return LocalRedirect(returnUrl);

    }
}
}
