using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using ProjetAlpha.Data;
using ProjetAlpha.Model;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;

namespace ProjetAlpha.Pages
{
    public class UpdateProfModel : PageModel
    {
         private readonly ApplicationDbContext _db ;
         [BindProperty]
        public InputModel Input { get; set; }
         public ApplicationUser user {get; set;}
         public string Pid {get; set;}
          public class InputModel{
                [Required] 
                public string Email { get; set; }
           public string Password { get; set; }
           public string Name {get;set;} 
            public string telephone{get;set;}
        }
         private ILogger<UpdateProfModel> _logger ;
           public UpdateProfModel (ILogger<UpdateProfModel> logger , ApplicationDbContext db)
        {
            _logger = logger;
            _db = db ;
        }

        public async Task OnGetAsync(string id)
        {
            
            user = await _db.ApplicationUser.FindAsync(id);
            Pid = id ;
        }

             public IActionResult OnPost(string id)
        {                          
              
            user = _db.ApplicationUser.Find(id);
            user.Name = Input.Name ;
            user.Email = Input.Email ;
            user.PasswordHash = Input.Password ;
            user.telephone = Input.telephone ;

            _db.ApplicationUser.Update(user);
            
            _db.SaveChanges();

            return RedirectToPage("/Index");
        }
    }
}
