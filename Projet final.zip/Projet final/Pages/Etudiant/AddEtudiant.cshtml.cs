﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using ProjetAlpha.Data;
using ProjetAlpha.Model;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;

namespace ProjetAlpha.Pages

{
    [Authorize]
    public class AddEtudiantModel : PageModel
    {
        private readonly ApplicationDbContext _db;

        public IEnumerable<Model.Filliere> Filliere { get; set; }
        [BindProperty]
        public InputModel Input { get; set; }

        public string ReturnUrl { get; set; }

        public AddEtudiantModel(ApplicationDbContext db)
        {
            _db = db;
        }
        public class InputModel
        {

            [Required]
            public string FullName { get; set; }
            [Required]
            public int Groupe { get; set; }
            [Required]
            public int FilliereID { get; set; }

        }

        public async Task OnGetAsync()
        {


            Filliere = await _db.Fillieres
             .ToListAsync();


        }


        public IActionResult OnPost(string returnUrl = null)
        {


            returnUrl = returnUrl ?? Url.Content("~/");
            if (ModelState.IsValid)
            {
                var et = new Model.Etudiant
                {
                    FullName = Input.FullName,
                    Groupe = Input.Groupe,
                    FilliereID = Input.FilliereID
                };

                _db.Etudiants.Add(et);

                _db.SaveChanges();

            }
            return LocalRedirect(returnUrl);

        }
    }

}