﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using ProjetAlpha.Data;
using ProjetAlpha.Model;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using System.Dynamic;

namespace ProjetAlpha.Pages
{
    [Authorize]
    public class MenuEtudiantModel : PageModel

    {
        dynamic mymodel = new ExpandoObject();


        private readonly ILogger<MenuEtudiantModel> _logger;


        private readonly ApplicationDbContext _db;

        public IEnumerable<Etudiant> Etudiants { get; set; }



        public MenuEtudiantModel(ILogger<MenuEtudiantModel> logger, ApplicationDbContext db)
        {
            _logger = logger;
            _db = db;
        }

        public async Task OnGetAsync()
        {
            Etudiants = await _db.Etudiants
            .ToListAsync();


        }
    }

}