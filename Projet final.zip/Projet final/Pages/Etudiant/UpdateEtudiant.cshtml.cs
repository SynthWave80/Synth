﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using ProjetAlpha.Data;
using ProjetAlpha.Model;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;

namespace ProjetAlpha.Pages
{
    [Authorize]
    public class UpdateEtudiantModel : PageModel
    {
        
        private readonly ApplicationDbContext _db;
        [BindProperty]
        public Etudiant mt { get; set; }
        public InputModel Input { get; set; }
        public int Mid { get; set; }

        public IEnumerable<Filliere> Filieres { get; set; }

        public class InputModel
        {

            [Required]
            public string Name { get; set; }
            [Required]
            public int IdFilliere { get; set; }
            [Required]
            public int groupe { get; set; }
            

        }
        private ILogger<UpdateEtudiantModel> _logger;


        public UpdateEtudiantModel(ILogger<UpdateEtudiantModel> logger, ApplicationDbContext db)
        {
            _logger = logger;
            _db = db;
        }
        public async Task OnGetAsync(int id)
        {
            Filieres = await _db.Fillieres
            .ToListAsync();

            mt = await _db.Etudiants.FindAsync(id);
            Mid = id;
        }

        public IActionResult OnPost(int id)
        {

            mt = _db.Etudiants.Find(id);
            mt.FullName = Input.Name;
            mt.FilliereID = Input.IdFilliere;
            mt.Groupe = Input.groupe;

            _db.Etudiants.Update(mt);

            _db.SaveChanges();

            return RedirectToPage("/Index");
        }

    }
}