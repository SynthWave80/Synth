using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using ProjetAlpha.Data;
using ProjetAlpha.Model;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;

namespace ProjetAlpha.Pages
{
    public class AddPresenceModel : PageModel
    {

        private readonly ApplicationDbContext _db;


        public IEnumerable<Model.Seance> Seances { get; set; }
        public IEnumerable<Model.Etudiant> Etudiants { get; set; }
        public IEnumerable<Model.Matiere> Matieres { get; set; }


        [BindProperty]
        public InputModel Input { get; set; }

        public string ReturnUrl { get; set; }

        public AddPresenceModel(ApplicationDbContext db)
        {
            _db = db;
        }
          public class InputModel
        {

            [Required]
            public int IdEtudiant { get; set; }
            [Required]
            public int IdSeance { get; set;}
            [Required]
            public int IdMatiere { get; set; }
            [Required]
            public DateTime DateTimes { get; set; }
        }
           public async Task OnGetAsync()
        {
            Seances = await _db.Seances
            .ToListAsync();

            Etudiants = await _db.Etudiants
             .ToListAsync();

            Matieres = await _db.Matiere
            .ToListAsync();

        }
        public IActionResult OnPost(string returnUrl = null)
        {


            returnUrl = returnUrl ?? Url.Content("~/");
            if (ModelState.IsValid)
            {
                var pr = new Model.Presence
                {
                    SeanceID = Input.IdSeance,
                    EtudiantID = Input.IdEtudiant,
                    MatiereID = Input.IdMatiere,
                    ToDate    = Input.DateTimes
                    
                };

                _db.Presences.Add(pr);

                _db.SaveChanges();

            }
            return LocalRedirect(returnUrl);

        }
    }
}
