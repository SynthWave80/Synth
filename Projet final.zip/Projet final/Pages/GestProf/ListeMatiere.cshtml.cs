﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using ProjetAlpha.Model ;
using ProjetAlpha.Data ;
using Microsoft.EntityFrameworkCore ;
using System.ComponentModel.DataAnnotations ;
using System.Linq ;
using Microsoft.AspNetCore.Identity ;

namespace ProjetAlpha.Pages
{
    public class ListeMatiereModel : PageModel
    {

        
        private readonly ILogger<ListeMatiereModel> _logger;

        private readonly UserManager<IdentityUser> _userManager;

        private readonly SignInManager<IdentityUser> _signInManager;


        private readonly ApplicationDbContext _db ;

        public IEnumerable<Model.Matiere> Matieres {get; set;}


        [Required]
        public string Id { get; set; }

        

        public ListeMatiereModel(SignInManager<IdentityUser> signInManager,

            ILogger<ListeMatiereModel> logger,

            UserManager<IdentityUser> userManager ,

            ApplicationDbContext db){

                _userManager = userManager;
                _signInManager = signInManager;
                _logger = logger;
                _db = db ;
            }


        public async Task OnGetAsync(string id)
        {
            Matieres = await _db.Matiere.Where( m => m.ProfID == id ).ToListAsync();
        }
    }
}
