﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using ProjetAlpha.Data;
using ProjetAlpha.Model;
using Microsoft.AspNetCore.Identity;

namespace ProjetAlpha.Pages.GestProf
{
    public class IndexModel : PageModel
    {


        private readonly ILogger<IndexModel> _logger;

        private readonly UserManager<IdentityUser> _userManager;
        private readonly SignInManager<IdentityUser> _signInManager;

        private readonly ApplicationDbContext _db;

        public ApplicationUser Prof { get; set; }


        public IndexModel(SignInManager<IdentityUser> signInManager,
            ILogger<IndexModel> logger,
            UserManager<IdentityUser> userManager,
            ApplicationDbContext db)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _logger = logger;
            _db = db;
        }

        public async Task OnGet()
        {
            var user = await _userManager.GetUserAsync(HttpContext.User);

            Prof = _db.ApplicationUser
                            .Where(PRF => PRF.Id == user.Id)
                            .First();

        }
    }
}
