using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace ProjetAlpha.Model
{
    public class GestionRole
    {
        public const string AdminUser="Admin" ;
         public const string ProfUser="Professeur" ;
    }
}