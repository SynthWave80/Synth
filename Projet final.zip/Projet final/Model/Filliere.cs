using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Microsoft.EntityFrameworkCore;


namespace ProjetAlpha.Model
{

    public class Filliere : DbContext
    {
    [Key] public int FilliereID{get;set;}

    [Required]public string name{get;set;}

    




    }






}