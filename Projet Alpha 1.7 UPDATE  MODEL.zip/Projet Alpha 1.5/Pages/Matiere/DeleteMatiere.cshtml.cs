using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using ProjetAlpha.Data;
using ProjetAlpha.Model;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;

namespace ProjetAlpha.Pages
{
    [Authorize]
    public class DeleteMatiereModel : PageModel
    {
        public Matiere fD { get; set; }

        private ILogger<DeleteMatiereModel> _logger;

        private readonly ApplicationDbContext _db;


        public DeleteMatiereModel(ILogger<DeleteMatiereModel> logger, ApplicationDbContext db)
        {
            _logger = logger;
            _db = db;
        }



        public void OnGet(int id)
        {
            fD = _db.Matiere.Find(id);
            _db.Matiere.Remove(fD);
            _db.SaveChanges();
        }
    }
}