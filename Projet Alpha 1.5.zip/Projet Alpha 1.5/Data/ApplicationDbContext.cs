﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using ProjetAlpha.Model;
using Microsoft.AspNetCore.Identity;

namespace ProjetAlpha.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        
        public DbSet<ApplicationUser> ApplicationUser {get;set;}
        public DbSet<Classe> Classes {get;set;}
        public DbSet<Etudiant> Etudiants {get;set;}
        public DbSet<Filliere> Fillieres {get;set;}
        public DbSet<Matiere> Matiere {get;set;}
        public DbSet<Presence> Presences {get;set;}     
        public DbSet<Seance> Seances {get;set;}
        public DbSet<user> users {get;set;}
        

        

        
       
        
    }
}
