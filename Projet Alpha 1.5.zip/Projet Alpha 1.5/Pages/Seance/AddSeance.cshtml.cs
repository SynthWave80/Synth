﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using ProjetAlpha.Data;
using ProjetAlpha.Model;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;

namespace ProjetAlpha.Pages
{
    [Authorize]
    public class AddSeanceModel : PageModel
    {
        private readonly ApplicationDbContext _db;


        public IEnumerable<Classe> Classes { get; set; }
        public IEnumerable<Matiere> Matieres { get; set; }
        

        [BindProperty]
        public InputModel Input { get; set; }

        public string ReturnUrl { get; set; }

        public AddSeanceModel(ApplicationDbContext db)
        {
            _db = db;
        }
        public class InputModel
        {

            [Required]
            public int IdMatieres { get; set; }
            [Required]
            public int IdClasses { get; set; }
            [Required]
            public DateTime Datetimes { get; set; }
            

        }

        public async Task OnGetAsync()
        {
            Classes = await _db.Classes
            .ToListAsync();

            Matieres = await _db.Matiere
             .ToListAsync();

            
        }

        public IActionResult OnPost(string returnUrl = null)
        {


            returnUrl = returnUrl ?? Url.Content("~/");
            if (ModelState.IsValid)
            {
                var et = new Seance
                {
                    classeID = Input.IdClasses,
                    ToDate = Input.Datetimes,
                    matiereID = Input.IdMatieres,
                    
                };

                _db.Seances.Add(et);

                _db.SaveChanges();

            }
            return LocalRedirect(returnUrl);

        }
    }
}


