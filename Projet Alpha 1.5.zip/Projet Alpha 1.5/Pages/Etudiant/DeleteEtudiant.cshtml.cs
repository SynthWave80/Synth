﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using ProjetAlpha.Data;
using ProjetAlpha.Model;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;

namespace ProjetAlpha.Pages
{
    [Authorize]
    public class DeleteEtudiantModel : PageModel
    {
        public Etudiant fD { get; set; }

        private ILogger<DeleteEtudiantModel> _logger;

        private readonly ApplicationDbContext _db;


        public DeleteEtudiantModel(ILogger<DeleteEtudiantModel> logger, ApplicationDbContext db)
        {
            _logger = logger;
            _db = db;
        }



        public void OnGet(int id)
        {
            fD = _db.Etudiants.Find(id);
            var result = _db.Etudiants.Remove(fD);
            _db.SaveChanges();
        }
    }
}