using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace ProjetAlpha.Model
{
public class Etudiant : DbContext
{
    [Key]     
    public int EtudiantID{get;set;}

    [Required]
    public string FullName{get;set;}

    [Required] public int ClasseID {get;set;}
     
    [ForeignKey("ClasseID")] public int Classe{get;set;}
    





}




}