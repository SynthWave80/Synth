using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace ProjetAlpha.Model
{
    public class Classe  : DbContext
    
        
    
    {

        [Key] public int ClasseID {get;set;}

        public int groupe{get;set;}

        public string name { get; set; }

        public int FilliereID{get;set;}

        
         
        [ForeignKey("FilliereID")] public Filliere Filiere{get;set;}


    }                                                                      



}
