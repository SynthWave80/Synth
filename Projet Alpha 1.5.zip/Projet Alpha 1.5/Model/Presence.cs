using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace ProjetAlpha.Model
{

    public class Presence : DbContext
    {
        [Key] public int PresenceID{get;set;}

     [Required] public int SeanceID {get;set;}
     [Required] public int EtudiantID {get;set;}

     [ForeignKey("SeanceID")] public Seance seance {get;set;}
     [ForeignKey("EtudiantID")] public Etudiant etudiant {get;set;}

      



    }


}