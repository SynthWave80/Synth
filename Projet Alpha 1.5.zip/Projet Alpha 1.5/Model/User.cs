using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace ProjetAlpha.Model
{

public class user : IdentityUser
{


[Required] public int status{get;set;}
[Required] public int Nom{get;set;}
[Required] public int Prenom{get;set;}





//if Status == 0 then its a prof , Else its Admin



}





}